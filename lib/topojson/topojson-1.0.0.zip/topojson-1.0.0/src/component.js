require("../topojson");

console.log(JSON.stringify({
  "name": "topojson",
  "version": topojson.version,
  "main": "./topojson.js"
}, null, 2));
